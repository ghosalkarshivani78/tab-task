﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using tasktab.Models;

namespace tasktab.Controllers
{
    public class contactController : Controller
    {
        //
        // GET: /contact/
        testEntities4 ts = new testEntities4();

        public ActionResult mainpage() 
        {
            List<contact> li = new List<contact>();
            return View(li);
        }

        public ActionResult tablecontactpartial()
        {
            List<contact> li = new List<contact>();
            var db=ts.usercontacts.ToList();
            foreach (var i in db) 
            {
                contact uc = new contact();
                uc.id = i.id;
                uc.name = i.name;
                uc.address = i.address;
                uc.phone = i.phone;
                li.Add(uc);
            }
            return View("tablecontactpartial",li);
        }

        [HttpGet]
        public ActionResult Create() 
        {
            contact c = new contact();
            return View("newcontactpartial",c);
        }


        [HttpPost]
        public ActionResult Create(contact u)
        {
            try
            {
                usercontact ui = new usercontact();
                ui.id = u.id;
                ui.name = u.name;
                ui.address = u.address;
                ui.phone = u.phone;
                ts.usercontacts.AddObject(ui);
                ts.SaveChanges();
                bool msg = false;
                return Json(msg);
                //return RedirectToAction("mainpage","Home");
            }
            catch
            {
                bool msg = true;
                return Json(msg);
            }
            
        }

        [HttpGet]
        public ActionResult Edit(int id) 
        {
            var t=ts.usercontacts.Where(x=>x.id==id).SingleOrDefault();
            contact u = new contact();
            u.id = t.id;
            u.name = t.name;
            u.address = t.address;
            u.phone = t.phone;
            return View("editcontactpartial",u);
        }

        [HttpPost]
        public ActionResult Edit(contact c) 
        {
            try
            {
                var t = ts.usercontacts.Where(x => x.id == c.id).SingleOrDefault();
                t.id = c.id;
                t.name = c.name;
                t.address = c.address;
                t.phone = c.phone;
                ts.SaveChanges();
                bool msg = false;
                return Json(msg);
                //return RedirectToAction("mainpage","Home");
            }
            catch 
            {
                bool msg = true;
                return Json(msg);
                //return View(c);
            }
        }

        [HttpGet]
        public ActionResult Delete(int id) 
        {
            try
            {
                var t = ts.usercontacts.Where(x => x.id == id).SingleOrDefault();
                ts.DeleteObject(t);
                ts.SaveChanges();
                return Json(true, JsonRequestBehavior.AllowGet);
            }
            catch 
            {
                return Json(false, JsonRequestBehavior.AllowGet);
            }
            //return RedirectToAction("mainpage","Home");
        }


        
    }
}
