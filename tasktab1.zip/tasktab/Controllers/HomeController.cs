﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using tasktab.Models;

namespace tasktab.Controllers
{
    public class HomeController : Controller
    {
        //
        // GET: /Home/
        testEntities4 ts = new testEntities4();

        public ActionResult Index()
        {
            login3 ui = new login3();
            return View(ui);
        }

        [HttpPost]
        public ActionResult login(login3 ui) 
        {
            var db = ts.logins.Where(x => x.username == ui.username && x.password == ui.password).ToList();
            if (db.Count > 0)
            {
                return RedirectToAction("mainpage");
            }
            else
            {
                ViewBag.msg = "Username or Password Incorrect";
                return View("Index",ui);
            }
        }

        public ActionResult mainpage() 
        {
            List<userform> li = new List<userform>();
            return View(li);
        }

        public ActionResult tablepartial()
        {
            var db = ts.userinfoes.ToList();
            List<userform> li = new List<userform>();
            foreach (var i in db)
            {
                userform u = new userform();
                u.id = i.id;
                u.name = i.name;
                u.email = i.email;
                u.phone = i.phone;
                li.Add(u);
            }
            return View("tablepartial", li);
        }

        //public ActionResult CreateNew() 
        //{
        //    userform u = new userform();
        //    return View("CreateNewpartial",u);
        //}

        public ActionResult Create()
        {
            userform u = new userform();
            return View("CreateNewpartial", u);
        }

        //
        // POST: /Home/Create

        [HttpPost]
        public ActionResult Create(userform uf)
        {
            try
            {
                    userinfo u = new userinfo();
                    u.name = uf.name;
                    u.email = uf.email;
                    u.password=uf.password;
                    u.phone = uf.phone;
                    ts.userinfoes.AddObject(u);
                    ts.SaveChanges();
                    bool msg = false;
                    return Json(msg);
                    //return RedirectToAction("mainpage");
              }
            catch
            {
                bool msg = true;
                return Json(msg);
            }
        }

        [HttpGet]
        public ActionResult Edit(int id) 
        {
            var uf = ts.userinfoes.Where(x => x.id == id).SingleOrDefault();
            userform u = new userform();
            u.id = uf.id;
            u.name = uf.name;
            u.email = uf.email;
            u.password = uf.password;
            u.phone = uf.phone;
            return View("editpartial",u);
        }

        [HttpPost]
        public ActionResult Edit(userform uf)
        {
            try
            {
                var ta = ts.userinfoes.Where(x => x.id == uf.id).SingleOrDefault();
                ta.name = uf.name;
                ta.email = uf.email;
                ta.password = uf.password;
                ta.phone = uf.phone;
                ts.SaveChanges();
                bool msg = false;
                return Json(msg);
                //return RedirectToAction("mainpage");
            }
            catch 
            {
                bool msg = true;
                return Json(msg);
                //return View(uf);
            }
        }

        public ActionResult Delete(int id) 
        {
            var t = ts.userinfoes.Where(x => x.id == id).SingleOrDefault();
            ts.DeleteObject(t);
            ts.SaveChanges();
            return RedirectToAction("mainpage");
        }


        public JsonResult setemailid(string email)
        {
        
            var t = ts.userinfoes.Where(x => x.email == email).FirstOrDefault();
            if (t != null)
            {
                return Json("1", JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json("0", JsonRequestBehavior.AllowGet);
            }

        }

    }
}
